package com.example.opbroadcast;

import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

public class ChatFreezeListener implements Listener {

    private final OpBroadcastPlugin plugin;

    public ChatFreezeListener(OpBroadcastPlugin plugin) {
        this.plugin = plugin;
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (!plugin.isChatFrozen()) return;

        // Staff (anyone who can run the broadcast commands) can still talk through a freeze.
        if (event.getPlayer().hasPermission("opbroadcast.use")) return;

        event.setCancelled(true);
        event.getPlayer().sendMessage(color(plugin.getConfig().getString(
                "messages.chat-frozen", "&cChat is frozen during a staff broadcast — please wait.")));
    }
}
