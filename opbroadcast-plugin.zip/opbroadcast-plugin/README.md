# OpBroadcast

Two commands, both op-only (`opbroadcast.use`, default: op):

- **`/broadcast <message>`** — sends a formatted text message to literally every
  player, regardless of whether they have Simple Voice Chat installed. This is
  the "everyone hears it either way" option, since real audio genuinely cannot
  reach a player without the Voice Chat mod — that's a limitation of Minecraft's
  protocol itself, not something any plugin can work around. It also freezes
  public chat for everyone except staff for a few seconds (configurable) and
  flashes a big "MESSAGE FROM STAFF" title/subtitle on every screen.

- **`/vbroadcast on`** / **`/vbroadcast off`** — toggles voice broadcast mode
  for the player who runs it. While it's on, anything they say into their mic
  is relayed directly to every other player who has Simple Voice Chat
  installed and connected, server-wide — not just players standing nearby,
  which is Voice Chat's normal behavior. Chat stays frozen and a
  "STAFF IS SPEAKING" title stays on screen the whole time it's active, and
  both clear automatically the moment you run `/vbroadcast off`. Players
  without the mod won't hear anything from this, no matter what — use
  `/broadcast` for them.

## Chat freeze behavior

- Staff (anyone with `opbroadcast.use`, default op) can always keep chatting
  through a freeze — it only blocks everyone else.
- `/broadcast`'s freeze auto-expires after `options.chat-freeze-seconds` (10s
  by default).
- `/vbroadcast on`'s freeze has no timer — it stays frozen until you run
  `/vbroadcast off`.

## Requirements

- Simple Voice Chat (the `voicechat` plugin) must be installed for `/vbroadcast`
  to work. If it's missing, `/vbroadcast` will tell you so and `/broadcast`
  (text) still works fine on its own.

## A heads-up on the voice part

Simple Voice Chat's plugin API is real and documented, and this is built
against it directly — but third-party APIs like this do shift slightly
between versions, and I can't run/test this against your exact server here.
If the build fails on the voice-related file specifically
(`VoiceBroadcastHandler.java`), it's almost certainly a small method-name
mismatch with your installed Voice Chat version rather than anything wrong
with your setup — paste me the build error and I'll adjust it, same as we've
done for the other plugin.

## Building

Same process as FullReset: upload this whole folder as a zip to a GitHub repo,
add `.github/workflows/build.yml` (already included here), and GitHub Actions
builds `OpBroadcast-1.0.0.jar` for you automatically — download it from the
Actions tab's Artifacts section once the run turns green.
